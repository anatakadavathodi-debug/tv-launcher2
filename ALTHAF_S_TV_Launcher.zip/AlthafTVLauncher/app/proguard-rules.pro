# ProGuard rules for ALTHAF, S TV Launcher
-keep class com.tvlauncher.app.** { *; }
