package com.tvlauncher.app.model

enum class ThemePreset(
    val id: String,
    val displayName: String,
    val accentHex: String,
    val bgStartHex: String,
    val bgCenterHex: String,
    val bgEndHex: String,
    val cardSurfaceHex: String
) {
    MIDNIGHT_OLED(
        id = "midnight_oled",
        displayName = "Midnight OLED",
        accentHex = "#0A84FF",
        bgStartHex = "#050507",
        bgCenterHex = "#0D1117",
        bgEndHex = "#000000",
        cardSurfaceHex = "#16181D"
    ),
    APPLE_SLATE(
        id = "apple_slate",
        displayName = "Apple TV Slate",
        accentHex = "#5E5CE6",
        bgStartHex = "#0C101A",
        bgCenterHex = "#151B2B",
        bgEndHex = "#080A10",
        cardSurfaceHex = "#1B2030"
    ),
    OBSIDIAN_BLUE(
        id = "obsidian_blue",
        displayName = "Obsidian Blue",
        accentHex = "#32ADE6",
        bgStartHex = "#060E1A",
        bgCenterHex = "#0E2138",
        bgEndHex = "#040810",
        cardSurfaceHex = "#132338"
    ),
    CINEMA_AMBER(
        id = "cinema_amber",
        displayName = "Cinema Amber",
        accentHex = "#FF9F0A",
        bgStartHex = "#120C06",
        bgCenterHex = "#1F150B",
        bgEndHex = "#0A0603",
        cardSurfaceHex = "#221912"
    );

    companion object {
        fun fromId(id: String?): ThemePreset =
            entries.firstOrNull { it.id == id } ?: APPLE_SLATE
    }
}

enum class IconStyle(val id: String, val displayName: String) {
    TV_BANNER("tv_banner", "Wide TV Banner (16:9)"),
    SQUIRCLE_APPLE("squircle_apple", "Apple TV Glass Card"),
    SQUARE_CARD("square_card", "Compact Square Icon");

    companion object {
        fun fromId(id: String?): IconStyle =
            entries.firstOrNull { it.id == id } ?: TV_BANNER
    }
}

enum class CornerRadiusPreset(val id: String, val displayName: String, val dpValue: Float) {
    SHARP("sharp", "Subtle (8dp)", 8f),
    ROUNDED("rounded", "Apple TV (16dp)", 16f),
    PILL("pill", "Soft (24dp)", 24f);

    companion object {
        fun fromId(id: String?): CornerRadiusPreset =
            entries.firstOrNull { it.id == id } ?: ROUNDED
    }
}

enum class AppSortOrder(val id: String, val displayName: String) {
    ALPHABETICAL("alphabetical", "Alphabetical (A–Z)"),
    RECENTLY_USED("recently_used", "Recently Used"),
    CUSTOM("custom", "Custom Order");

    companion object {
        fun fromId(id: String?): AppSortOrder =
            entries.firstOrNull { it.id == id } ?: ALPHABETICAL
    }
}

enum class WallpaperMode(val id: String, val displayName: String) {
    THEME_GRADIENT("theme_gradient", "Theme Ambient Gradient"),
    GALLERY_IMAGE("gallery_image", "Custom Gallery Wallpaper");

    companion object {
        fun fromId(id: String?): WallpaperMode =
            entries.firstOrNull { it.id == id } ?: THEME_GRADIENT
    }
}
