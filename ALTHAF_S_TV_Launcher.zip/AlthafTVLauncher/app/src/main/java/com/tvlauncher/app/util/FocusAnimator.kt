package com.tvlauncher.app.util

import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

object FocusAnimator {

    private val overshootInterpolator = OvershootInterpolator(1.35f)
    private val decelerateInterpolator = DecelerateInterpolator(1.5f)

    fun animateCardFocus(
        cardView: View,
        focusRing: View?,
        labelView: View?,
        hasFocus: Boolean,
        isTopShelf: Boolean = false
    ) {
        val targetScale = when {
            !hasFocus -> 1.0f
            isTopShelf -> 1.08f
            else -> 1.10f
        }
        val targetElevation = if (hasFocus) 28f else 4f
        val duration = if (hasFocus) 210L else 160L
        val interpolator = if (hasFocus) overshootInterpolator else decelerateInterpolator

        cardView.animate().cancel()
        cardView.animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .translationZ(targetElevation)
            .setDuration(duration)
            .setInterpolator(interpolator)
            .start()

        focusRing?.let { ring ->
            ring.animate().cancel()
            ring.animate()
                .alpha(if (hasFocus) 1.0f else 0.0f)
                .setDuration(duration)
                .start()
        }

        labelView?.let { label ->
            label.animate().cancel()
            label.animate()
                .alpha(if (hasFocus) 1.0f else 0.72f)
                .scaleX(if (hasFocus) 1.04f else 1.0f)
                .scaleY(if (hasFocus) 1.04f else 1.0f)
                .setDuration(duration)
                .start()
        }
    }

    fun animateButtonFocus(view: View, hasFocus: Boolean) {
        val targetScale = if (hasFocus) 1.06f else 1.0f
        view.animate().cancel()
        view.animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .setDuration(170L)
            .setInterpolator(if (hasFocus) overshootInterpolator else decelerateInterpolator)
            .start()
    }
}
