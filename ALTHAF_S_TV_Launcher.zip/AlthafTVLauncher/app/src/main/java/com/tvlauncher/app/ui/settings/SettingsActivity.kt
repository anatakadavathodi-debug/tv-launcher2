package com.tvlauncher.app.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.tvlauncher.app.R
import com.tvlauncher.app.data.PrefsManager
import com.tvlauncher.app.model.AppSortOrder
import com.tvlauncher.app.model.CornerRadiusPreset
import com.tvlauncher.app.model.IconStyle
import com.tvlauncher.app.model.ThemePreset
import com.tvlauncher.app.model.WallpaperMode
import com.tvlauncher.app.util.FocusAnimator
import com.tvlauncher.app.util.ThemeHelper

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var rootView: View
    private lateinit var ivWallpaper: ImageView
    private lateinit var viewScrim: View

    private lateinit var tvThemeValue: TextView
    private lateinit var tvIconStyleValue: TextView
    private lateinit var tvCornerRadiusValue: TextView
    private lateinit var tvShowLabelsValue: TextView
    private lateinit var tvSortOrderValue: TextView
    private lateinit var tvSideloadedValue: TextView
    private lateinit var tvWallpaperModeValue: TextView
    private lateinit var tvWallpaperDimValue: TextView
    private lateinit var tvHiddenAppsValue: TextView

    private val galleryPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            prefs.customWallpaperUri = uri.toString()
            prefs.wallpaperMode = WallpaperMode.GALLERY_IMAGE
            refreshUi()
            Toast.makeText(this, "Custom wallpaper applied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = PrefsManager(this)
        bindViews()
        setupListeners()
        refreshUi()
    }

    private fun bindViews() {
        rootView = findViewById(R.id.rootSettingsContainer)
        ivWallpaper = findViewById(R.id.ivSettingsWallpaper)
        viewScrim = findViewById(R.id.viewSettingsScrim)

        tvThemeValue = findViewById(R.id.tvValueTheme)
        tvIconStyleValue = findViewById(R.id.tvValueIconStyle)
        tvCornerRadiusValue = findViewById(R.id.tvValueCornerRadius)
        tvShowLabelsValue = findViewById(R.id.tvValueShowLabels)
        tvSortOrderValue = findViewById(R.id.tvValueSortOrder)
        tvSideloadedValue = findViewById(R.id.tvValueSideloaded)
        tvWallpaperModeValue = findViewById(R.id.tvValueWallpaperMode)
        tvWallpaperDimValue = findViewById(R.id.tvValueWallpaperDim)
        tvHiddenAppsValue = findViewById(R.id.tvValueHiddenApps)
    }

    private fun setupListeners() {
        val settingRows = listOf(
            R.id.rowSettingTheme,
            R.id.rowSettingIconStyle,
            R.id.rowSettingCornerRadius,
            R.id.rowSettingShowLabels,
            R.id.rowSettingSortOrder,
            R.id.rowSettingSideloaded,
            R.id.rowSettingPickWallpaper,
            R.id.rowSettingResetWallpaper,
            R.id.rowSettingWallpaperDim,
            R.id.rowSettingRestoreHidden,
            R.id.rowSettingDefaultHome,
            R.id.btnSettingsBack
        )

        settingRows.forEach { id ->
            findViewById<View>(id).setOnFocusChangeListener { v, hasFocus ->
                FocusAnimator.animateButtonFocus(v, hasFocus)
            }
        }

        findViewById<LinearLayout>(R.id.rowSettingTheme).setOnClickListener {
            val entries = ThemePreset.entries
            val next = entries[(entries.indexOf(prefs.themePreset) + 1) % entries.size]
            prefs.themePreset = next
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingIconStyle).setOnClickListener {
            val entries = IconStyle.entries
            val next = entries[(entries.indexOf(prefs.iconStyle) + 1) % entries.size]
            prefs.iconStyle = next
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingCornerRadius).setOnClickListener {
            val entries = CornerRadiusPreset.entries
            val next = entries[(entries.indexOf(prefs.cornerRadius) + 1) % entries.size]
            prefs.cornerRadius = next
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingShowLabels).setOnClickListener {
            prefs.showAppLabels = !prefs.showAppLabels
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingSortOrder).setOnClickListener {
            val entries = AppSortOrder.entries
            val next = entries[(entries.indexOf(prefs.sortOrder) + 1) % entries.size]
            prefs.sortOrder = next
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingSideloaded).setOnClickListener {
            prefs.includeSideloadedApps = !prefs.includeSideloadedApps
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingPickWallpaper).setOnClickListener {
            try {
                galleryPickerLauncher.launch(arrayOf("image/*"))
            } catch (_: Exception) {
                Toast.makeText(this, "No image picker available on this TV", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<LinearLayout>(R.id.rowSettingResetWallpaper).setOnClickListener {
            prefs.wallpaperMode = WallpaperMode.THEME_GRADIENT
            prefs.customWallpaperUri = null
            refreshUi()
            Toast.makeText(this, "Reset to theme ambient gradient", Toast.LENGTH_SHORT).show()
        }

        findViewById<LinearLayout>(R.id.rowSettingWallpaperDim).setOnClickListener {
            val current = prefs.wallpaperDimPercent
            val next = if (current >= 80) 20 else current + 15
            prefs.wallpaperDimPercent = next
            refreshUi()
        }

        findViewById<LinearLayout>(R.id.rowSettingRestoreHidden).setOnClickListener {
            val hidden = prefs.getHiddenPackages().toList()
            if (hidden.isEmpty()) {
                Toast.makeText(this, "No hidden apps", Toast.LENGTH_SHORT).show()
            } else {
                hidden.forEach { prefs.unhideApp(it) }
                refreshUi()
                Toast.makeText(this, "Restored ${hidden.size} hidden app(s)", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<LinearLayout>(R.id.rowSettingDefaultHome).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (_: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this, "Open Android Settings > Apps > Default Home", Toast.LENGTH_LONG).show()
                }
            }
        }

        findViewById<TextView>(R.id.btnSettingsBack).setOnClickListener {
            finish()
        }
    }

    private fun refreshUi() {
        ThemeHelper.applyBackground(
            context = this,
            prefs = prefs,
            wallpaperImageView = ivWallpaper,
            scrimView = viewScrim,
            rootView = rootView
        )

        tvThemeValue.text = prefs.themePreset.displayName
        tvIconStyleValue.text = prefs.iconStyle.displayName
        tvCornerRadiusValue.text = prefs.cornerRadius.displayName
        tvShowLabelsValue.text = if (prefs.showAppLabels) "Shown" else "Hidden"
        tvSortOrderValue.text = prefs.sortOrder.displayName
        tvSideloadedValue.text = if (prefs.includeSideloadedApps) "Included" else "TV Apps Only"
        tvWallpaperModeValue.text = prefs.wallpaperMode.displayName
        tvWallpaperDimValue.text = "${prefs.wallpaperDimPercent}%"
        val hiddenCount = prefs.getHiddenPackages().size
        tvHiddenAppsValue.text = if (hiddenCount == 0) "None" else "$hiddenCount Hidden (Tap to Restore)"
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }
}
