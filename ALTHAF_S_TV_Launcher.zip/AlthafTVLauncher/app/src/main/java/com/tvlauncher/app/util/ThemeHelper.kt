package com.tvlauncher.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.View
import android.widget.ImageView
import com.tvlauncher.app.data.PrefsManager
import com.tvlauncher.app.model.ThemePreset
import com.tvlauncher.app.model.WallpaperMode

object ThemeHelper {

    fun createThemeBackgroundDrawable(preset: ThemePreset): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                Color.parseColor(preset.bgStartHex),
                Color.parseColor(preset.bgCenterHex),
                Color.parseColor(preset.bgEndHex)
            )
        )
    }

    fun createFocusRingDrawable(accentHex: String, cornerRadiusPx: Float, strokeWidthPx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = cornerRadiusPx
            setColor(Color.TRANSPARENT)
            setStroke(strokeWidthPx, Color.parseColor(accentHex))
        }
    }

    fun createCardSurfaceDrawable(surfaceHex: String, cornerRadiusPx: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = cornerRadiusPx
            setColor(Color.parseColor(surfaceHex))
        }
    }

    fun applyBackground(
        context: Context,
        prefs: PrefsManager,
        wallpaperImageView: ImageView,
        scrimView: View,
        rootView: View
    ) {
        val theme = prefs.themePreset
        rootView.background = createThemeBackgroundDrawable(theme)

        val dimAlpha = (prefs.wallpaperDimPercent / 100f).coerceIn(0.15f, 0.85f)
        scrimView.setBackgroundColor(Color.argb((dimAlpha * 255).toInt(), 0, 0, 0))

        val uriStr = prefs.customWallpaperUri
        if (prefs.wallpaperMode == WallpaperMode.GALLERY_IMAGE && !uriStr.isNullOrBlank()) {
            val bitmap = decodeSampledBitmapFromUri(context, Uri.parse(uriStr), 1920, 1080)
            if (bitmap != null) {
                wallpaperImageView.setImageBitmap(bitmap)
                wallpaperImageView.visibility = View.VISIBLE
                return
            }
        }

        wallpaperImageView.setImageDrawable(null)
        wallpaperImageView.visibility = View.GONE
    }

    private fun decodeSampledBitmapFromUri(
        context: Context,
        uri: Uri,
        reqWidth: Int,
        reqHeight: Int
    ): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }
            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun dpToPx(context: Context, dp: Float): Float =
        dp * context.resources.displayMetrics.density
}
