package com.tvlauncher.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import com.tvlauncher.app.model.AppCategory
import com.tvlauncher.app.model.AppInfo
import com.tvlauncher.app.model.AppRow
import com.tvlauncher.app.model.AppSortOrder

class AppRepository(
    private val context: Context,
    private val prefs: PrefsManager
) {
    private val pm: PackageManager = context.packageManager

    fun loadAllInstalledApps(includeHidden: Boolean = false): List<AppInfo> {
        val lastUsedMap = prefs.getLastUsedMap()
        val pinnedList = prefs.getPinnedPackages()
        val hiddenSet = prefs.getHiddenPackages()

        val appMap = linkedMapOf<String, AppInfo>()

        // 1. Primary Android TV (Leanback) apps
        val leanbackIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        }
        val leanbackResolved = queryIntentActivitiesCompat(leanbackIntent)
        for (info in leanbackResolved) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == context.packageName) continue
            if (!includeHidden && hiddenSet.contains(pkg)) continue
            if (!appMap.containsKey(pkg)) {
                appMap[pkg] = buildAppInfo(info, isTvApp = true, lastUsedMap, pinnedList)
            }
        }

        // 2. Standard Launcher apps (sideloaded or hybrid apps) if enabled
        if (prefs.includeSideloadedApps) {
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val launcherResolved = queryIntentActivitiesCompat(launcherIntent)
            for (info in launcherResolved) {
                val pkg = info.activityInfo?.packageName ?: continue
                if (pkg == context.packageName) continue
                if (!includeHidden && hiddenSet.contains(pkg)) continue
                if (!appMap.containsKey(pkg)) {
                    appMap[pkg] = buildAppInfo(info, isTvApp = false, lastUsedMap, pinnedList)
                }
            }
        }

        return sortApps(appMap.values.toList())
    }

    fun buildHomeRows(allApps: List<AppInfo>): List<AppRow> {
        if (allApps.isEmpty()) return emptyList()

        val rows = mutableListOf<AppRow>()
        val pinnedOrder = prefs.getPinnedPackages()

        // Row 1: Pinned / Favorites Top Shelf
        val pinnedApps = pinnedOrder.mapNotNull { pkg -> allApps.firstOrNull { it.packageName == pkg } }
        if (pinnedApps.isNotEmpty()) {
            rows.add(
                AppRow(
                    id = "row_favorites",
                    title = "Favorites",
                    apps = pinnedApps,
                    isTopShelf = true
                )
            )
        } else {
            // Show Top Shelf with up to 6 TV apps on first run so screen feels full & premium
            val featured = allApps.filter { it.isTvApp }.ifEmpty { allApps }.take(6)
            rows.add(
                AppRow(
                    id = "row_top_shelf",
                    title = "Quick Launch",
                    apps = featured,
                    isTopShelf = true
                )
            )
        }

        // Row 2: Streaming & Media
        val streamingApps = allApps.filter { it.category == AppCategory.STREAMING_MEDIA }
        if (streamingApps.isNotEmpty()) {
            rows.add(
                AppRow(
                    id = "row_streaming",
                    title = AppCategory.STREAMING_MEDIA.title,
                    apps = streamingApps
                )
            )
        }

        // Row 3: Games
        val gameApps = allApps.filter { it.category == AppCategory.GAMES }
        if (gameApps.isNotEmpty()) {
            rows.add(
                AppRow(
                    id = "row_games",
                    title = AppCategory.GAMES.title,
                    apps = gameApps
                )
            )
        }

        // Row 4: Apps & Utilities (if any distinct from all)
        val utilityApps = allApps.filter { it.category == AppCategory.UTILITIES }
        if (utilityApps.isNotEmpty() && (streamingApps.isNotEmpty() || gameApps.isNotEmpty())) {
            rows.add(
                AppRow(
                    id = "row_utilities",
                    title = AppCategory.UTILITIES.title,
                    apps = utilityApps
                )
            )
        }

        // Row 5: All Installed Apps
        rows.add(
            AppRow(
                id = "row_all_apps",
                title = AppCategory.ALL_APPS.title,
                apps = allApps
            )
        )

        return rows
    }

    fun launchApp(packageName: String): Boolean {
        val launchIntent = pm.getLeanbackLaunchIntentForPackage(packageName)
            ?: pm.getLaunchIntentForPackage(packageName)
            ?: return false

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launchIntent)
            prefs.recordAppLaunch(packageName)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun sortApps(apps: List<AppInfo>): List<AppInfo> {
        return when (prefs.sortOrder) {
            AppSortOrder.ALPHABETICAL -> apps.sortedBy { it.label.lowercase() }
            AppSortOrder.RECENTLY_USED -> apps.sortedWith(
                compareByDescending<AppInfo> { it.lastUsedTimestamp }
                    .thenBy { it.label.lowercase() }
            )
            AppSortOrder.CUSTOM -> {
                val order = prefs.getCustomAppOrder()
                val orderMap = order.withIndex().associate { (index, pkg) -> pkg to index }
                apps.sortedWith(
                    compareBy<AppInfo> { orderMap[it.packageName] ?: Int.MAX_VALUE }
                        .thenBy { it.label.lowercase() }
                )
            }
        }
    }

    private fun buildAppInfo(
        resolveInfo: ResolveInfo,
        isTvApp: Boolean,
        lastUsedMap: Map<String, Long>,
        pinnedList: List<String>
    ): AppInfo {
        val activityInfo = resolveInfo.activityInfo
        val pkg = activityInfo.packageName
        val label = resolveInfo.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg

        val banner: Drawable? = try {
            activityInfo.loadBanner(pm) ?: pm.getApplicationBanner(pkg)
        } catch (_: Exception) {
            null
        }

        val icon: Drawable = try {
            resolveInfo.loadIcon(pm)
        } catch (_: Exception) {
            pm.defaultActivityIcon
        }

        val category = detectCategory(pkg, label, activityInfo.applicationInfo)

        return AppInfo(
            packageName = pkg,
            label = label,
            activityName = activityInfo.name,
            banner = banner,
            icon = icon,
            isTvApp = isTvApp,
            category = category,
            lastUsedTimestamp = lastUsedMap[pkg] ?: 0L,
            isPinned = pinnedList.contains(pkg)
        )
    }

    private fun detectCategory(
        packageName: String,
        label: String,
        appInfo: ApplicationInfo?
    ): AppCategory {
        val pkgLower = packageName.lowercase()
        val labelLower = label.lowercase()

        if (appInfo != null) {
            when (appInfo.category) {
                ApplicationInfo.CATEGORY_GAME -> return AppCategory.GAMES
                ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_AUDIO,
                ApplicationInfo.CATEGORY_NEWS -> return AppCategory.STREAMING_MEDIA
            }
        }

        val mediaKeywords = listOf(
            "netflix", "youtube", "prime", "amazon", "disney", "hotstar", "hulu",
            "plex", "kodi", "vlc", "spotify", "twitch", "hbo", "max", "appletv",
            "tv", "video", "player", "music", "media", "stream", "sonyliv", "zee5",
            "jiocinema", "sunnxt", "manorama"
        )
        if (mediaKeywords.any { pkgLower.contains(it) || labelLower.contains(it) }) {
            return AppCategory.STREAMING_MEDIA
        }

        val gameKeywords = listOf("game", "play.games", "retroarch", "ppsspp", "dolphin", "asphalt")
        if (gameKeywords.any { pkgLower.contains(it) || labelLower.contains(it) }) {
            return AppCategory.GAMES
        }

        return AppCategory.UTILITIES
    }

    @Suppress("DEPRECATION")
    private fun queryIntentActivitiesCompat(intent: Intent): List<ResolveInfo> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            pm.queryIntentActivities(intent, 0)
        }
    }
}
