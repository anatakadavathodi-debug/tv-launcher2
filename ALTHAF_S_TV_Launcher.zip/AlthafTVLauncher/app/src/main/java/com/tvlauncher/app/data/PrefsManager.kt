package com.tvlauncher.app.data

import android.content.Context
import android.content.SharedPreferences
import com.tvlauncher.app.model.AppSortOrder
import com.tvlauncher.app.model.CornerRadiusPreset
import com.tvlauncher.app.model.IconStyle
import com.tvlauncher.app.model.ThemePreset
import com.tvlauncher.app.model.WallpaperMode
import org.json.JSONArray
import org.json.JSONObject

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var themePreset: ThemePreset
        get() = ThemePreset.fromId(prefs.getString(KEY_THEME, ThemePreset.APPLE_SLATE.id))
        set(value) = prefs.edit().putString(KEY_THEME, value.id).apply()

    var iconStyle: IconStyle
        get() = IconStyle.fromId(prefs.getString(KEY_ICON_STYLE, IconStyle.TV_BANNER.id))
        set(value) = prefs.edit().putString(KEY_ICON_STYLE, value.id).apply()

    var cornerRadius: CornerRadiusPreset
        get() = CornerRadiusPreset.fromId(prefs.getString(KEY_CORNER_RADIUS, CornerRadiusPreset.ROUNDED.id))
        set(value) = prefs.edit().putString(KEY_CORNER_RADIUS, value.id).apply()

    var sortOrder: AppSortOrder
        get() = AppSortOrder.fromId(prefs.getString(KEY_SORT_ORDER, AppSortOrder.ALPHABETICAL.id))
        set(value) = prefs.edit().putString(KEY_SORT_ORDER, value.id).apply()

    var wallpaperMode: WallpaperMode
        get() = WallpaperMode.fromId(prefs.getString(KEY_WALLPAPER_MODE, WallpaperMode.THEME_GRADIENT.id))
        set(value) = prefs.edit().putString(KEY_WALLPAPER_MODE, value.id).apply()

    var customWallpaperUri: String?
        get() = prefs.getString(KEY_WALLPAPER_URI, null)
        set(value) = prefs.edit().putString(KEY_WALLPAPER_URI, value).apply()

    var wallpaperDimPercent: Int
        get() = prefs.getInt(KEY_WALLPAPER_DIM, 48).coerceIn(15, 85)
        set(value) = prefs.edit().putInt(KEY_WALLPAPER_DIM, value.coerceIn(15, 85)).apply()

    var showAppLabels: Boolean
        get() = prefs.getBoolean(KEY_SHOW_LABELS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_LABELS, value).apply()

    var includeSideloadedApps: Boolean
        get() = prefs.getBoolean(KEY_INCLUDE_SIDELOADED, true)
        set(value) = prefs.edit().putBoolean(KEY_INCLUDE_SIDELOADED, value).apply()

    fun getPinnedPackages(): List<String> = readOrderedList(KEY_PINNED_PACKAGES)

    fun setPinnedPackages(packages: List<String>) {
        writeOrderedList(KEY_PINNED_PACKAGES, packages.distinct())
    }

    fun isPinned(packageName: String): Boolean = getPinnedPackages().contains(packageName)

    fun togglePin(packageName: String): Boolean {
        val current = getPinnedPackages().toMutableList()
        val nowPinned = if (current.contains(packageName)) {
            current.remove(packageName)
            false
        } else {
            current.add(packageName)
            true
        }
        setPinnedPackages(current)
        return nowPinned
    }

    fun movePinnedApp(packageName: String, delta: Int): Boolean {
        val current = getPinnedPackages().toMutableList()
        val index = current.indexOf(packageName)
        if (index == -1) return false
        val target = (index + delta).coerceIn(0, current.lastIndex)
        if (target == index) return false
        current.removeAt(index)
        current.add(target, packageName)
        setPinnedPackages(current)
        return true
    }

    fun getHiddenPackages(): Set<String> =
        prefs.getStringSet(KEY_HIDDEN_PACKAGES, emptySet())?.toSet() ?: emptySet()

    fun hideApp(packageName: String) {
        val updated = getHiddenPackages().toMutableSet()
        updated.add(packageName)
        prefs.edit().putStringSet(KEY_HIDDEN_PACKAGES, updated).apply()
        val pinned = getPinnedPackages().toMutableList()
        if (pinned.remove(packageName)) {
            setPinnedPackages(pinned)
        }
    }

    fun unhideApp(packageName: String) {
        val updated = getHiddenPackages().toMutableSet()
        updated.remove(packageName)
        prefs.edit().putStringSet(KEY_HIDDEN_PACKAGES, updated).apply()
    }

    fun getCustomAppOrder(): List<String> = readOrderedList(KEY_CUSTOM_ORDER)

    fun setCustomAppOrder(order: List<String>) {
        writeOrderedList(KEY_CUSTOM_ORDER, order.distinct())
    }

    fun ensureCustomOrderContains(allPackages: List<String>) {
        val current = getCustomAppOrder().toMutableList()
        var changed = false
        for (pkg in allPackages) {
            if (!current.contains(pkg)) {
                current.add(pkg)
                changed = true
            }
        }
        if (changed) {
            setCustomAppOrder(current)
        }
    }

    fun moveAppInCustomOrder(packageName: String, allVisiblePackages: List<String>, delta: Int): Boolean {
        ensureCustomOrderContains(allVisiblePackages)
        val order = getCustomAppOrder().toMutableList()
        val currentIndex = order.indexOf(packageName)
        if (currentIndex == -1) return false
        val targetIndex = (currentIndex + delta).coerceIn(0, order.lastIndex)
        if (targetIndex == currentIndex) return false
        order.removeAt(currentIndex)
        order.add(targetIndex, packageName)
        setCustomAppOrder(order)
        sortOrder = AppSortOrder.CUSTOM
        return true
    }

    fun recordAppLaunch(packageName: String) {
        val map = getLastUsedMap().toMutableMap()
        map[packageName] = System.currentTimeMillis()
        val json = JSONObject()
        map.forEach { (k, v) -> json.put(k, v) }
        prefs.edit().putString(KEY_LAST_USED_MAP, json.toString()).apply()
    }

    fun getLastUsedMap(): Map<String, Long> {
        val raw = prefs.getString(KEY_LAST_USED_MAP, null) ?: return emptyMap()
        return try {
            val json = JSONObject(raw)
            val result = mutableMapOf<String, Long>()
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                result[key] = json.optLong(key, 0L)
            }
            result
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun readOrderedList(key: String): List<String> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i -> arr.getString(i) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeOrderedList(key: String, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "althaf_tv_launcher_prefs"
        private const val KEY_THEME = "theme_preset"
        private const val KEY_ICON_STYLE = "icon_style"
        private const val KEY_CORNER_RADIUS = "corner_radius"
        private const val KEY_SORT_ORDER = "sort_order"
        private const val KEY_WALLPAPER_MODE = "wallpaper_mode"
        private const val KEY_WALLPAPER_URI = "wallpaper_uri"
        private const val KEY_WALLPAPER_DIM = "wallpaper_dim"
        private const val KEY_SHOW_LABELS = "show_app_labels"
        private const val KEY_INCLUDE_SIDELOADED = "include_sideloaded"
        private const val KEY_PINNED_PACKAGES = "pinned_packages"
        private const val KEY_HIDDEN_PACKAGES = "hidden_packages"
        private const val KEY_CUSTOM_ORDER = "custom_app_order"
        private const val KEY_LAST_USED_MAP = "last_used_map"
    }
}
