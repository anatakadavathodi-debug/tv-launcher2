package com.tvlauncher.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvlauncher.app.R
import com.tvlauncher.app.data.PrefsManager
import com.tvlauncher.app.model.AppInfo
import com.tvlauncher.app.model.AppRow

class AppRowAdapter(
    private val prefs: PrefsManager,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppMenu: (AppInfo) -> Unit,
    private val onAppFocused: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppRowAdapter.RowViewHolder>() {

    private var rows: List<AppRow> = emptyList()
    private val viewPool = RecyclerView.RecycledViewPool()

    fun submitRows(newRows: List<AppRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_row, parent, false)
        return RowViewHolder(view)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        holder.bind(rows[position])
    }

    override fun getItemCount(): Int = rows.size

    inner class RowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRowTitle: TextView = itemView.findViewById(R.id.tvRowTitle)
        private val rvApps: RecyclerView = itemView.findViewById(R.id.rvHorizontalApps)

        init {
            rvApps.layoutManager = LinearLayoutManager(
                itemView.context,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            rvApps.setRecycledViewPool(viewPool)
            rvApps.clipChildren = false
            rvApps.clipToPadding = false
        }

        fun bind(row: AppRow) {
            tvRowTitle.text = row.title
            rvApps.adapter = AppCardAdapter(
                apps = row.apps,
                isTopShelf = row.isTopShelf,
                prefs = prefs,
                onAppClick = onAppClick,
                onAppMenu = onAppMenu,
                onAppFocused = onAppFocused
            )
        }
    }
}
