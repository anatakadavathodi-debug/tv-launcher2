package com.tvlauncher.app.model

import android.graphics.drawable.Drawable

enum class AppCategory(val title: String) {
    FAVORITES("Favorites"),
    STREAMING_MEDIA("Streaming & Media"),
    GAMES("Games"),
    UTILITIES("Apps & Utilities"),
    ALL_APPS("All Installed Apps")
}

data class AppInfo(
    val packageName: String,
    val label: String,
    val activityName: String,
    val banner: Drawable?,
    val icon: Drawable,
    val isTvApp: Boolean,
    val category: AppCategory,
    val lastUsedTimestamp: Long = 0L,
    val isPinned: Boolean = false
)

data class AppRow(
    val id: String,
    val title: String,
    val apps: List<AppInfo>,
    val isTopShelf: Boolean = false
)
