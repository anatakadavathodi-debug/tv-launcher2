package com.tvlauncher.app.ui.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import com.tvlauncher.app.R
import com.tvlauncher.app.model.AppInfo
import com.tvlauncher.app.util.FocusAnimator

class AppContextDialog(
    context: Context,
    private val app: AppInfo,
    private val isPinned: Boolean,
    private val onAction: (Action) -> Unit
) : Dialog(context) {

    enum class Action {
        LAUNCH,
        TOGGLE_PIN,
        MOVE_LEFT,
        MOVE_RIGHT,
        HIDE,
        APP_INFO,
        UNINSTALL
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_app_context)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val ivIcon = findViewById<ImageView>(R.id.ivDialogAppIcon)
        val tvTitle = findViewById<TextView>(R.id.tvDialogAppTitle)
        val tvPkg = findViewById<TextView>(R.id.tvDialogAppPackage)

        ivIcon.setImageDrawable(app.icon)
        tvTitle.text = app.label
        tvPkg.text = app.packageName

        val btnLaunch = findViewById<TextView>(R.id.btnActionLaunch)
        val btnPin = findViewById<TextView>(R.id.btnActionPin)
        val btnMoveLeft = findViewById<TextView>(R.id.btnActionMoveLeft)
        val btnMoveRight = findViewById<TextView>(R.id.btnActionMoveRight)
        val btnHide = findViewById<TextView>(R.id.btnActionHide)
        val btnInfo = findViewById<TextView>(R.id.btnActionInfo)
        val btnUninstall = findViewById<TextView>(R.id.btnActionUninstall)

        btnPin.text = if (isPinned) "Unpin from Favorites" else "Pin to Favorites"

        val buttons = listOf(
            btnLaunch to Action.LAUNCH,
            btnPin to Action.TOGGLE_PIN,
            btnMoveLeft to Action.MOVE_LEFT,
            btnMoveRight to Action.MOVE_RIGHT,
            btnHide to Action.HIDE,
            btnInfo to Action.APP_INFO,
            btnUninstall to Action.UNINSTALL
        )

        buttons.forEach { (view, action) ->
            view.setOnFocusChangeListener { v, hasFocus ->
                FocusAnimator.animateButtonFocus(v, hasFocus)
            }
            view.setOnClickListener {
                dismiss()
                onAction(action)
            }
        }

        btnLaunch.requestFocus()
    }
}
