package com.tvlauncher.app.ui.adapter

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.tvlauncher.app.R
import com.tvlauncher.app.data.PrefsManager
import com.tvlauncher.app.model.AppInfo
import com.tvlauncher.app.model.IconStyle
import com.tvlauncher.app.util.FocusAnimator
import com.tvlauncher.app.util.ThemeHelper

class AppCardAdapter(
    private val apps: List<AppInfo>,
    private val isTopShelf: Boolean,
    private val prefs: PrefsManager,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppMenu: (AppInfo) -> Unit,
    private val onAppFocused: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppCardAdapter.AppViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_card, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(apps[position])
    }

    override fun getItemCount(): Int = apps.size

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardContainer: CardView = itemView.findViewById(R.id.cardApp)
        private val focusRing: View = itemView.findViewById(R.id.viewFocusRing)
        private val ivBanner: ImageView = itemView.findViewById(R.id.ivAppBanner)
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvLabel: TextView = itemView.findViewById(R.id.tvAppLabel)
        private val ivPinnedBadge: ImageView = itemView.findViewById(R.id.ivPinnedBadge)

        fun bind(app: AppInfo) {
            val ctx = itemView.context
            val theme = prefs.themePreset
            val style = prefs.iconStyle
            val radiusPx = ThemeHelper.dpToPx(ctx, prefs.cornerRadius.dpValue)
            val strokePx = ThemeHelper.dpToPx(ctx, 2.5f).toInt().coerceAtLeast(2)

            // Card size based on style & top-shelf status
            val (widthDp, heightDp) = when (style) {
                IconStyle.TV_BANNER -> if (isTopShelf) 244f to 138f else 208f to 118f
                IconStyle.SQUIRCLE_APPLE -> if (isTopShelf) 172f to 140f else 148f to 120f
                IconStyle.SQUARE_CARD -> if (isTopShelf) 144f to 144f else 124f to 124f
            }

            val cardLp = cardContainer.layoutParams
            cardLp.width = ThemeHelper.dpToPx(ctx, widthDp).toInt()
            cardLp.height = ThemeHelper.dpToPx(ctx, heightDp).toInt()
            cardContainer.layoutParams = cardLp

            val ringLp = focusRing.layoutParams
            ringLp.width = cardLp.width + ThemeHelper.dpToPx(ctx, 8f).toInt()
            ringLp.height = cardLp.height + ThemeHelper.dpToPx(ctx, 8f).toInt()
            focusRing.layoutParams = ringLp

            cardContainer.radius = radiusPx
            cardContainer.setCardBackgroundColor(android.graphics.Color.parseColor(theme.cardSurfaceHex))
            focusRing.background = ThemeHelper.createFocusRingDrawable(theme.accentHex, radiusPx + 4f, strokePx)
            focusRing.alpha = 0f

            // Banner vs Icon rendering
            if (style == IconStyle.TV_BANNER && app.banner != null) {
                ivBanner.setImageDrawable(app.banner)
                ivBanner.visibility = View.VISIBLE
                ivIcon.visibility = View.GONE
            } else {
                ivBanner.visibility = View.GONE
                ivIcon.visibility = View.VISIBLE
                ivIcon.setImageDrawable(app.icon)
            }

            tvLabel.text = app.label
            tvLabel.visibility = if (prefs.showAppLabels) View.VISIBLE else View.GONE
            tvLabel.alpha = 0.72f
            ivPinnedBadge.visibility = if (app.isPinned) View.VISIBLE else View.GONE

            itemView.setOnFocusChangeListener { _, hasFocus ->
                FocusAnimator.animateCardFocus(
                    cardView = cardContainer,
                    focusRing = focusRing,
                    labelView = tvLabel,
                    hasFocus = hasFocus,
                    isTopShelf = isTopShelf
                )
                if (hasFocus) {
                    onAppFocused(app)
                }
            }

            itemView.setOnClickListener {
                onAppClick(app)
            }

            itemView.setOnLongClickListener {
                onAppMenu(app)
                true
            }

            itemView.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN &&
                    (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO)
                ) {
                    onAppMenu(app)
                    true
                } else {
                    false
                }
            }
        }
    }
}
