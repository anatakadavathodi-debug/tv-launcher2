package com.tvlauncher.app.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvlauncher.app.R
import com.tvlauncher.app.data.AppRepository
import com.tvlauncher.app.data.PrefsManager
import com.tvlauncher.app.model.AppInfo
import com.tvlauncher.app.ui.adapter.AppRowAdapter
import com.tvlauncher.app.ui.dialog.AppContextDialog
import com.tvlauncher.app.ui.settings.SettingsActivity
import com.tvlauncher.app.util.FocusAnimator
import com.tvlauncher.app.util.NetworkHelper
import com.tvlauncher.app.util.ThemeHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var repository: AppRepository
    private lateinit var rowAdapter: AppRowAdapter

    private lateinit var rootContainer: View
    private lateinit var ivWallpaper: ImageView
    private lateinit var viewScrim: View
    private lateinit var rvRows: RecyclerView
    private lateinit var tvClock: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvNetwork: TextView
    private lateinit var tvFocusedAppInfo: TextView
    private lateinit var btnSettings: LinearLayout
    private lateinit var btnSystemSettings: LinearLayout
    private lateinit var tvEmptyState: TextView

    private var currentAllApps: List<AppInfo> = emptyList()
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockAndStatus()
            clockHandler.postDelayed(this, 30_000L)
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsManager(this)
        repository = AppRepository(this, prefs)

        bindViews()
        setupTopBar()
        setupRowsRecycler()
        setupBackNavigation()
        registerPackageListener()

        applyThemeAndWallpaper()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        applyThemeAndWallpaper()
        loadApps()
        updateClockAndStatus()
        clockHandler.postDelayed(clockRunnable, 30_000L)
    }

    override fun onPause() {
        super.onPause()
        clockHandler.removeCallbacks(clockRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            openSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun bindViews() {
        rootContainer = findViewById(R.id.rootHomeContainer)
        ivWallpaper = findViewById(R.id.ivHomeWallpaper)
        viewScrim = findViewById(R.id.viewWallpaperScrim)
        rvRows = findViewById(R.id.rvAppRows)
        tvClock = findViewById(R.id.tvTopClock)
        tvDate = findViewById(R.id.tvTopDate)
        tvNetwork = findViewById(R.id.tvTopNetwork)
        tvFocusedAppInfo = findViewById(R.id.tvFocusedAppHint)
        btnSettings = findViewById(R.id.btnTopSettings)
        btnSystemSettings = findViewById(R.id.btnTopSystemSettings)
        tvEmptyState = findViewById(R.id.tvEmptyState)
    }

    private fun setupTopBar() {
        listOf(btnSettings, btnSystemSettings).forEach { btn ->
            btn.setOnFocusChangeListener { v, hasFocus ->
                FocusAnimator.animateButtonFocus(v, hasFocus)
            }
        }

        btnSettings.setOnClickListener {
            openSettings()
        }

        btnSystemSettings.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Unable to open Android Settings", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupRowsRecycler() {
        rowAdapter = AppRowAdapter(
            prefs = prefs,
            onAppClick = { app -> launchApp(app) },
            onAppMenu = { app -> showAppContextMenu(app) },
            onAppFocused = { app ->
                val tag = if (app.isPinned) "Pinned • " else ""
                tvFocusedAppInfo.text = "$tag${app.label}  •  OK to Open  •  Hold OK or Menu for Options"
            }
        )

        rvRows.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        rvRows.adapter = rowAdapter
        rvRows.clipChildren = false
        rvRows.clipToPadding = false
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Consume Back on the default HOME screen, smoothly scroll back to top
                rvRows.smoothScrollToPosition(0)
            }
        })
    }

    private fun registerPackageListener() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    private fun applyThemeAndWallpaper() {
        ThemeHelper.applyBackground(
            context = this,
            prefs = prefs,
            wallpaperImageView = ivWallpaper,
            scrimView = viewScrim,
            rootView = rootContainer
        )
    }

    private fun loadApps() {
        lifecycleScope.launch {
            val (apps, rows) = withContext(Dispatchers.IO) {
                val installed = repository.loadAllInstalledApps()
                val builtRows = repository.buildHomeRows(installed)
                installed to builtRows
            }
            currentAllApps = apps
            rowAdapter.submitRows(rows)
            tvEmptyState.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE

            if (rows.isNotEmpty() && !rvRows.hasFocus() && !btnSettings.hasFocus() && !btnSystemSettings.hasFocus()) {
                rvRows.post {
                    rvRows.getChildAt(0)?.requestFocus()
                }
            }
        }
    }

    private fun launchApp(app: AppInfo) {
        val launched = repository.launchApp(app.packageName)
        if (!launched) {
            Toast.makeText(this, "Could not launch ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppContextMenu(app: AppInfo) {
        val isPinned = prefs.isPinned(app.packageName)
        AppContextDialog(
            context = this,
            app = app,
            isPinned = isPinned
        ) { action ->
            when (action) {
                AppContextDialog.Action.LAUNCH -> launchApp(app)
                AppContextDialog.Action.TOGGLE_PIN -> {
                    val nowPinned = prefs.togglePin(app.packageName)
                    Toast.makeText(
                        this,
                        if (nowPinned) "Pinned ${app.label} to Favorites" else "Removed ${app.label} from Favorites",
                        Toast.LENGTH_SHORT
                    ).show()
                    loadApps()
                }
                AppContextDialog.Action.MOVE_LEFT -> moveApp(app, -1)
                AppContextDialog.Action.MOVE_RIGHT -> moveApp(app, 1)
                AppContextDialog.Action.HIDE -> {
                    prefs.hideApp(app.packageName)
                    Toast.makeText(this, "Hidden ${app.label}", Toast.LENGTH_SHORT).show()
                    loadApps()
                }
                AppContextDialog.Action.APP_INFO -> repository.openAppInfo(app.packageName)
                AppContextDialog.Action.UNINSTALL -> repository.uninstallApp(app.packageName)
            }
        }.show()
    }

    private fun moveApp(app: AppInfo, delta: Int) {
        val visiblePkgs = currentAllApps.map { it.packageName }
        val movedPinned = if (prefs.isPinned(app.packageName)) {
            prefs.movePinnedApp(app.packageName, delta)
        } else {
            false
        }
        val movedCustom = prefs.moveAppInCustomOrder(app.packageName, visiblePkgs, delta)
        if (movedPinned || movedCustom) {
            loadApps()
        } else {
            Toast.makeText(this, "Already at edge of list", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.fade_in_scale, R.anim.fade_out)
    }

    private fun updateClockAndStatus() {
        val now = Date()
        val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        val dateFmt = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
        tvClock.text = timeFmt.format(now)
        tvDate.text = dateFmt.format(now)
        tvNetwork.text = NetworkHelper.getNetworkLabel(this)
    }
}
